LEGENDAS :

(AS LEGENDAS FUNCIONAM NO CAMPO DAS APOSTAS E DOS GATILHOS)

D1 - duzia 1
D2 - duzia 2
D3 - duzia 3
C1 - coluna 1
C2 - coluna 2
C3 - coluna 3
H - numeros altos
L - numeros baixos
R - numeros vermelhos
B - numeros pretos
O - numeros impares
P - números pares
T0 - terminais 0
T1 - terminais 1
T2 - terminais 2
T3 - terminais 3
T4 - terminais 4
T5 - terminais 5
T6 - terminais 6
T7 - terminais 7
T8 - terminais 8
T9 - terminais 9
N - neutro (confirma qualquer jogada)

BOT MAX GOLD IA

